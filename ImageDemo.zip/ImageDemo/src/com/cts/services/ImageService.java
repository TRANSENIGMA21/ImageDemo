package com.cts.services;

import java.io.File;

import javax.ws.rs.GET;
import javax.ws.rs.MatrixParam;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.NewCookie;
import javax.ws.rs.core.Response;

@Path("/ImageService")
public class ImageService {
	@GET
	@Produces("image/jpg")
	public Response DownloadImage(){
		
		
		
		File file=new File("C:/Hibernate Training/images/first.jpg");
		
		return Response
				 .status(200)
		            .header("Access-Control-Allow-Origin", "*")
		            .header("Access-Control-Allow-Headers", "origin, content-type, accept, authorization")
		            .header("Access-Control-Allow-Credentials", "true")
		            .header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS, HEAD")
		            .header("Access-Control-Max-Age", "1209600")
		            .entity((Object)file)
		            .build();
		
		
	}
	
	/*Demo of Matrix Param*/
	
	//ImageService/GetData/3256;eventName=training
	@GET
	@Path("/GetData/{eventId}")
	@Produces("text/plain")
	public Response getData(@PathParam("eventId")int eventId,@MatrixParam("eventName") String eventName){
		
		
		String data="Recieved "+eventName+" with "+eventId;
		
		
		return Response.ok().entity(data).cookie
				(new NewCookie("cookieResponse",data)).build();
		
		
		/*return Response
				 .status(200)
		            .header("Access-Control-Allow-Origin", "*")
		            .header("Access-Control-Allow-Headers", "origin, content-type, accept, authorization")
		            .header("Access-Control-Allow-Credentials", "true")
		            .header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS, HEAD")
		            .header("Access-Control-Max-Age", "1209600")
		            .entity(data)
		            .build();*/
		
		
		
	}
	
	
}
